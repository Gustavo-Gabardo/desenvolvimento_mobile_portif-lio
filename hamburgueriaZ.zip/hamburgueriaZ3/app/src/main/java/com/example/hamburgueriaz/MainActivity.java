package com.example.hamburgueriaz;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText edtNome;
    CheckBox chkBacon, chkQueijo, chkOnion;
    TextView txtQuantidade, txtPreco, txtResumo;
    int quantidade = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        chkBacon = findViewById(R.id.chkBacon);
        chkQueijo = findViewById(R.id.chkQueijo);
        chkOnion = findViewById(R.id.chkOnion);
        txtQuantidade = findViewById(R.id.txtQuantidade);
        txtPreco = findViewById(R.id.txtPreco);
        txtResumo = findViewById(R.id.txtResumo);

        findViewById(R.id.btnAdicionar).setOnClickListener(v -> somar());
        findViewById(R.id.btnSubtrair).setOnClickListener(v -> subtrair());
        findViewById(R.id.btnEnviar).setOnClickListener(v -> enviarPedido());

        // Atualizar preço ao marcar/desmarcar os adicionais
        chkBacon.setOnCheckedChangeListener((buttonView, isChecked) -> atualizarPreco());
        chkQueijo.setOnCheckedChangeListener((buttonView, isChecked) -> atualizarPreco());
        chkOnion.setOnCheckedChangeListener((buttonView, isChecked) -> atualizarPreco());
    }

    public void somar() {
        quantidade++;
        atualizarQuantidade();
    }

    public void subtrair() {
        if (quantidade > 0) {
            quantidade--;
        }
        atualizarQuantidade();
    }

    public void atualizarQuantidade() {
        txtQuantidade.setText(String.valueOf(quantidade));
        atualizarPreco();
    }

    public void atualizarPreco() {
        double preco = 20 * quantidade;
        if (chkBacon.isChecked()) preco += 2 * quantidade;
        if (chkQueijo.isChecked()) preco += 2 * quantidade;
        if (chkOnion.isChecked()) preco += 3 * quantidade;
        txtPreco.setText("Preço: R$ " + preco);
    }

    public void enviarPedido() {
        String nome = edtNome.getText().toString().trim();

        // Validação do nome
        if (nome.isEmpty()) {
            Toast.makeText(this, "Por favor, insira seu nome antes de enviar o pedido.", Toast.LENGTH_SHORT).show();
            return;
        }

        String bacon = chkBacon.isChecked() ? "Sim" : "Não";
        String queijo = chkQueijo.isChecked() ? "Sim" : "Não";
        String onion = chkOnion.isChecked() ? "Sim" : "Não";

        double preco = 20 * quantidade;
        if (chkBacon.isChecked()) preco += 2 * quantidade;
        if (chkQueijo.isChecked()) preco += 2 * quantidade;
        if (chkOnion.isChecked()) preco += 3 * quantidade;

        String resumo = "Nome: " + nome + "\n" +
                "Tem Bacon? " + bacon + "\n" +
                "Tem Queijo? " + queijo + "\n" +
                "Tem Onion Rings? " + onion + "\n" +
                "Quantidade: " + quantidade + "\n" +
                "Preço final: R$ " + preco;

        txtResumo.setText(resumo);

        // Criando o Intent para enviar o pedido
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Pedido de " + nome);
        emailIntent.putExtra(Intent.EXTRA_TEXT, resumo);

        // Verifica se há um app disponível para o Intent
        if (emailIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(Intent.createChooser(emailIntent, "Escolha um aplicativo para exportar o pedido"));
            Toast.makeText(this, "Pedido enviado com sucesso!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Nenhum aplicativo disponível para exportar o pedido.", Toast.LENGTH_SHORT).show();
        }
    }
}
